##### Terms

1. You agree to not violate any laws in your jurisdiction.

2. You may not download copyrighted material from YouTube.

TL;DR: Use Cercube for good, not evil.
